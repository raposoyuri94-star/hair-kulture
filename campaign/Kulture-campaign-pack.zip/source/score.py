"""An original understated 18-second instrumental and paper-reveal sound design.
Uses Python's standard library only; no sampled music or reference-video audio.
Run from any directory: python campaign/source/score.py
"""
from array import array
from math import sin, pi, exp, tanh
from pathlib import Path
import random
import wave

RATE = 48000
DURATION = 18
random.seed(2026)
events = []

def note(time, frequency, duration, gain, pan=0):
    events.append((time, frequency, duration, gain, pan))

# A spacious original F-minor / D-flat / A-flat / E-flat progression.
chords = [(174.614, 207.652, 261.626), (138.591, 174.614, 207.652),
          (207.652, 261.626, 311.127), (155.563, 195.998, 233.082)]
for idx, chord in enumerate(chords):
    for j, frequency in enumerate(chord):
        note(idx * 4.4, frequency / 2, 5.1, .045, (j - 1) * .35)
        note(idx * 4.4 + .18 * j, frequency * 2, 3.2, .035, (1 - j) * .45)

for time, freq in [(3.4, 523.251), (4.7, 622.254), (6.0, 523.251),
                   (8.5, 415.305), (11.3, 622.254), (13.0, 523.251),
                   (14.2, 415.305), (15.0, 523.251), (15.75, 698.456)]:
    note(time, freq, 2.5, .075, sin(time) * .45)

left = array('f', [0]) * (RATE * DURATION)
right = array('f', [0]) * (RATE * DURATION)
for start, freq, duration, gain, pan in events:
    for j in range(min(int(duration * RATE), len(left) - int(start * RATE))):
        t = j / RATE
        env = min(1, t / .08) * exp(-t / (duration * .45)) * min(1, (duration - t) / .3)
        # Soft electric-piano harmonics with slight natural beating.
        tone = sin(2*pi*freq*t) + .22*sin(2*pi*freq*2.003*t) + .07*sin(2*pi*freq*3*t)
        value = tone * env * gain
        k = int(start * RATE) + j
        left[k] += value * (1-pan*.6)
        right[k] += value * (1+pan*.6)

# A restrained low pulse under the middle of the film, 82 beats per minute.
for beat in range(16):
    start = 4.7 + beat * 60/82
    for j in range(int(.28 * RATE)):
        k = int(start*RATE)+j
        if k >= len(left): break
        t=j/RATE
        kick=.10*exp(-t*19)*sin(2*pi*(47*t+1.5*(1-exp(-t*20))))
        left[k]+=kick;right[k]+=kick

# Filtered, original paper-rustle and soft transition swishes.
for start, duration, gain in [(1.35, 1.9, .12), (4.55, .36, .035), (8.35, .36, .035), (11.15, .36, .035), (14.05, .55, .045)]:
    low=0
    for j in range(int(duration*RATE)):
        k=int(start*RATE)+j
        if k>=len(left): break
        p=j/(duration*RATE)
        low=.84*low+.16*random.uniform(-1,1)
        flutter=.4+.6*abs(sin(j/RATE*41))
        value=low*sin(pi*p)**1.3*flutter*gain
        left[k]+=value*(1-.25*p);right[k]+=value*(.75+.25*p)

pcm=array('h')
peak=0
for i,(l,r) in enumerate(zip(left,right)):
    t=i/RATE
    fade=min(1,t/.5,max(0,(DURATION-t)/1.25))
    for value in (l,r):
        value=tanh(value*1.45)*fade
        peak=max(peak,abs(value))
        pcm.append(round(value*32767))

output=Path(__file__).resolve().parents[1]/'assets'/'kulture-original-score.wav'
with wave.open(str(output),'wb') as wav:
    wav.setnchannels(2);wav.setsampwidth(2);wav.setframerate(RATE);wav.writeframes(pcm.tobytes())
print(f'Saved {output.name}: {DURATION}s stereo, peak {peak:.3f}, no clipping.')
